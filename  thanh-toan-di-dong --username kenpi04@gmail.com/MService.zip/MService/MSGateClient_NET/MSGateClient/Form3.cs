﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using cryption;
using MSGateClient.MSGatewayProxy;
using System.Threading;

namespace MSGateClient
{
    
    public partial class Form3 : Form
    {
        static MSFunctionClient client;
        static LoginResponse loginRes;
        static DateTime timer;
        static Random random = new Random();
        public Form3()
        {
            InitializeComponent();

        }

        private void purBillpay_Click(object sender, EventArgs e)
        {
            //for (int i = 0; i < 1; i++)
            //{
            //    Thread myThread = new Thread(() => payBill());
                //myThread.Start();
                //System.Console.WriteLine("call webservice");
            //    Thread.Sleep(2000);
            //}
            payBill();

        }        

        public void payBill()
        {
            System.Console.WriteLine("pay billllllllllllll");
            DateTime timeSec = DateTime.Now;
            TimeSpan tspan = timeSec.Subtract(timer);
            if (tspan.Minutes > 10)
            {
                login();
            }
            else
                timer = timeSec;
            string dataSign = "";
            string privateKeyPath = "private.plaptest.kez"; // duong dan toi private key de sign du lieu

            Cryption cr = new Cryption();

            BillpayRequest bpr = new BillpayRequest();
            bpr.accountID = this.txtAcc.Text;//"0909000008";
            bpr.amount = long.Parse(txtAmountBillPay.Text);
            bpr.billpayid = this.txtBillPayId.Text;//"110";
            bpr.channel = 102;//int.Parse(txtChannelBillpay.Text);//102;
            bpr.transID = 1000000 + random.Next(1000000) + "";
            bpr.sessionID = loginRes.sessionID;

            dataSign = bpr.billpayid + "_" + bpr.accountID + "_"
                        + bpr.amount + "_" + bpr.transID + "_"
                        + bpr.channel + "_" + bpr.sessionID;
            dataSign = cr.signData(dataSign, cr.GetKeyFromFile(privateKeyPath));
            bpr.dataSign = dataSign;

            System.Console.WriteLine("11111111");
            StandardMSResponse stMSRes = client.billpay(bpr);
                System.Console.WriteLine("222222222");
                sttBillPay.Text = "Result Code : " + stMSRes.resultCode + "\n" +
                                  "Result Name :" + stMSRes.resultName + "\n" +
                                  "Transid     : " + stMSRes.transID + "\n" +
                                  "Description : " + stMSRes.description + "\n" +
                                  "Debit amount: " + stMSRes.debitAmount;
        }

        private void Form3_Load(object sender, EventArgs e)
        {
            loginStt.Text = login();
            
        }

        private static string login()
        {
            string username = "plaptest";
            string password = "plap@pwd";
            string agentpin = "000000";
            string dataSign = "";

            string publicKeyPath = "public.mservice.pke"; // duong dan toi public key de ma hoa/ verify
            string privateKeyPath = "private.plaptest.kez"; // duong dan toi private key de sign du lieu

            //string username = "worldnet";
            //string password = "wnet#123ms";
            //string agentpin = "290912";
            //string dataSign = "";

            //string publicKeyPath = "public.msproduction.pke"; // duong dan toi public key de ma hoa/ verify
            //string privateKeyPath = "private.plaptest.kez"; // duong dan toi private key de sign du lieu


            Cryption cr = new Cryption();
            password = Cryption.EncryptMessage(password, cr.GetKeyFromFile(publicKeyPath));
            agentpin = Cryption.EncryptMessage(agentpin, cr.GetKeyFromFile(publicKeyPath));
            dataSign = cr.signData(username + "_" + password, cr.GetKeyFromFile(privateKeyPath));

            client = new MSFunctionClient();
            loginRes = new LoginResponse();
            loginRes = client.login(username, password, agentpin, dataSign);
            int result = loginRes.resultCode;
            if(result == 0)
            {
                timer = DateTime.Now;
            }
            string description = loginRes.description;
            
            return description;
        }

        private void okTopUp_Click(object sender, EventArgs e)
        {
            DateTime timeSec = DateTime.Now;
            TimeSpan tspan = timeSec.Subtract(timer);
            if (tspan.Minutes > 10)
            {
                login();
            }
            else
                timer = timeSec;
            string dataSign = "";
            
            string privateKeyPath = "private.plaptest.kez"; // duong dan toi private key de sign du lieu

            Cryption cr = new Cryption();
           

            TopupAirtimeRequest topUpIns = new TopupAirtimeRequest();
            topUpIns.phoneNumber = txtPhoneTopUp.Text;//"01681234567";
            topUpIns.amount = long.Parse(txtAmountTopup.Text);
            topUpIns.channel = 102;//int.Parse(txtChannelTopup.Text);//1;
            topUpIns.sessionID = loginRes.sessionID;
            topUpIns.transID = random.Next(1000000).ToString(); 
            dataSign =  topUpIns.phoneNumber + "_" + topUpIns.amount + "_" 
                        + topUpIns.transID + "_" + topUpIns.channel + "_" 
                        + topUpIns.sessionID;
            
            Console.WriteLine(dataSign);
            dataSign = cr.signData(dataSign, cr.GetKeyFromFile(privateKeyPath));
            topUpIns.dataSign = dataSign;
            

            StandardMSResponse stMSRes = client.topupAirtime(topUpIns);
            topUpStt.Text =   "Result Code: " + stMSRes.resultCode + "\n" +
                //"Result Name:" + stMSRes.resultName + "\n" +
                              "Transid    : " + stMSRes.transID + "\n" +
                              "Description: " + stMSRes.description; //+ "\n" +
                              //"Data Sign:" + stMSRes.dataSign;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            okTopUp_Click(sender, e);
        }

      

        

        
    }
}

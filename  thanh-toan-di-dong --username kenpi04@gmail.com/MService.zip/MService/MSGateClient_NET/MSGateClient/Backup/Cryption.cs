﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.Security.Cryptography;
using System.Linq;
using System.Text;
using System.IO;

namespace cryption
{
    class Cryption
    {
        public string EncryptString(string inputString, int dwKeySize, string xmlString)
        {
            RSACryptoServiceProvider rsaCryptoServiceProvider = new RSACryptoServiceProvider(dwKeySize);
            rsaCryptoServiceProvider.FromXmlString(xmlString);
            int keySize = dwKeySize / 8;
            byte[] bytes = Encoding.UTF32.GetBytes(inputString);
            int maxLength = keySize - 42;
            int dataLength = bytes.Length;
            int iterations = dataLength / maxLength;
            StringBuilder stringBuilder = new StringBuilder();
            for (int i = 0; i <= iterations; i++)
            {
                byte[] tempBytes = new byte[(dataLength - maxLength * i > maxLength) ? maxLength : dataLength - maxLength * i];
                Buffer.BlockCopy(bytes, maxLength * i, tempBytes, 0, tempBytes.Length);
                byte[] encryptedBytes = rsaCryptoServiceProvider.Encrypt(tempBytes, true);
                Array.Reverse(encryptedBytes);
                stringBuilder.Append(Convert.ToBase64String(encryptedBytes));
            }
            return stringBuilder.ToString();
        }

        public string DecryptString(string inputString, int dwKeySize, string xmlString)
        {
            RSACryptoServiceProvider rsaCryptoServiceProvider = new RSACryptoServiceProvider(dwKeySize);
            rsaCryptoServiceProvider.FromXmlString(xmlString);
            int base64BlockSize = ((dwKeySize / 8) % 3 != 0) ? (((dwKeySize / 8) / 3) * 4) + 4 : ((dwKeySize / 8) / 3) * 4;
            int iterations = inputString.Length / base64BlockSize;
            ArrayList arrayList = new ArrayList();
            for (int i = 0; i < iterations; i++)
            {
                byte[] encryptedBytes = Convert.FromBase64String(inputString.Substring(base64BlockSize * i, base64BlockSize));
                Array.Reverse(encryptedBytes);
                arrayList.AddRange(rsaCryptoServiceProvider.Decrypt(encryptedBytes, true));
            }
            return Encoding.UTF32.GetString(arrayList.ToArray(Type.GetType("System.Byte")) as byte[]);
        }

        public string GetKeyFromFile(string Path)
        {
            StreamReader stream = new StreamReader(Path);
            string data = stream.ReadToEnd();
            stream.Close();
            return data;
        }




        public bool verifyData(string orgData, string signedData, string xmlKey)
        {
            bool result = false;
            try
            {
                byte[] dataBytes = Encoding.UTF8.GetBytes(orgData);
                byte[] signatureBytes = Convert.FromBase64String(signedData);
                RSACryptoServiceProvider provider = new RSACryptoServiceProvider();
                provider.FromXmlString(xmlKey);
                result = provider.VerifyData(dataBytes, "SHA", signatureBytes);
            }
            catch (CryptographicException CEx)
            {
                //MessageBox.Show("ERROR: \nOne of the following has occured.\nThe cryptographic service provider cannot be acquired.\nThe length of the text being encrypted is greater than the maximum allowed length.\nThe OAEP padding is not supported on this computer.\n" + "Exact error: " + CEx.Message); 
            }
            catch (Exception Ex)
            {
                //MessageBox.Show("ERROR: \n" + Ex.Message); 
            }


            return result;
        }



        public string signData(string orgData, string xmlKey)
        {
            string result = "";
            try
            {
                byte[] dataBytes = Encoding.UTF8.GetBytes(orgData);
                RSACryptoServiceProvider provider = new RSACryptoServiceProvider();
                provider.FromXmlString(xmlKey);
                byte[] signatureBytes = provider.SignData(dataBytes, "SHA");
                result = Convert.ToBase64String(signatureBytes);
            }
            catch (CryptographicException CEx)
            {
                //MessageBox.Show("ERROR: \nOne of the following has occured.\nThe cryptographic service provider cannot be acquired.\nThe length of the text being encrypted is greater than the maximum allowed length.\nThe OAEP padding is not supported on this computer.\n" + "Exact error: " + CEx.Message); 
            }
            catch (Exception Ex)
            {
                //    MessageBox.Show("ERROR: \n" + Ex.Message); 
            }


            return result;

        }



        public static String EncryptMessage(String message, String pubKey)
        {
            RSACryptoServiceProvider serviceRSA = CreateServiceRSA(pubKey, 1024);
            byte[] input = String2ArrByte(message);
            byte[] output = EncryptDecryptData(serviceRSA, true, input);
            return base64Encode(output);
        }

        public static String DecryptMessage(String message, String priKey)
        {
            RSACryptoServiceProvider serviceRSA = CreateServiceRSA(priKey, 1024);
            byte[] input = base64Decode(message);
            byte[] output = EncryptDecryptData(serviceRSA, false, input);
            return ArrByte2String(output);
        }
        private static RSACryptoServiceProvider CreateServiceRSA(String key, int keySize)
        {
            RSACryptoServiceProvider serviceRSA = new RSACryptoServiceProvider(keySize);
            serviceRSA.FromXmlString(key); // import private key | public key
            return serviceRSA;
        }

        private static byte[] EncryptDecryptData(RSACryptoServiceProvider serviceRSA, bool isEncrypt, byte[] input)
        {
            bool fOAEP = false;
            if (isEncrypt)
                return serviceRSA.Encrypt(input, fOAEP); // mã hóa
            else
                return serviceRSA.Decrypt(input, fOAEP); // giải mã
        }
        public static byte[] String2ArrByte(String data) { return Encoding.UTF8.GetBytes(data); }

        public static String ArrByte2String(byte[] data) { return Encoding.UTF8.GetString(data); }

        public static byte[] HexString2ArrByte(String data)
        {
            byte[] result = new byte[data.Length / 2];
            for (int i = 0; i < data.Length; i += 2)
                result[i / 2] = Convert.ToByte(data.Substring(i, 2), 16);
            return result;
        }

        public static String ArrByte2HexString(byte[] data)
        {
            StringBuilder result = new StringBuilder();
            for (int i = 0; i < data.Length; i++)
                result.Append(data[i].ToString("X2"));
            //result.Append(data[i].ToString());
            return result.ToString();
        }
        public static string base64Encode(byte[] data)
        {
            try
            {
                string encodedData = Convert.ToBase64String(data);
                return encodedData;
            }
            catch (Exception e)
            {
                throw new Exception("Error in base64Encode" + e.Message);
            }
        }
        public static byte[] base64Decode(string data)
        {
            try
            {
                System.Text.UTF8Encoding encoder = new System.Text.UTF8Encoding();
                System.Text.Decoder utf8Decode = encoder.GetDecoder();

                byte[] todecode_byte = Convert.FromBase64String(data);
                return todecode_byte;
            }
            catch (Exception e)
            {
                throw new Exception("Error in base64Decode" + e.Message);
            }
        }
    }
}

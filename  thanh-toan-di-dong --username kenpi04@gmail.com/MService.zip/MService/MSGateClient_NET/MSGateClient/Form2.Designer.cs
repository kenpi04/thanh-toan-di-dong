﻿namespace MSGateClient
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabController = new System.Windows.Forms.TabControl();
            this.billpayTab = new System.Windows.Forms.TabPage();
            this.clickOk = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.txtTrans = new System.Windows.Forms.TextBox();
            this.txtAmount = new System.Windows.Forms.TextBox();
            this.topUp = new System.Windows.Forms.TabPage();
            this.label3 = new System.Windows.Forms.Label();
            this.sttLogin = new System.Windows.Forms.Label();
            this.tabController.SuspendLayout();
            this.billpayTab.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabController
            // 
            this.tabController.Controls.Add(this.billpayTab);
            this.tabController.Controls.Add(this.topUp);
            this.tabController.Location = new System.Drawing.Point(12, 12);
            this.tabController.Name = "tabController";
            this.tabController.SelectedIndex = 0;
            this.tabController.Size = new System.Drawing.Size(733, 292);
            this.tabController.TabIndex = 0;
            // 
            // billpayTab
            // 
            this.billpayTab.Controls.Add(this.clickOk);
            this.billpayTab.Controls.Add(this.label2);
            this.billpayTab.Controls.Add(this.label1);
            this.billpayTab.Controls.Add(this.txtTrans);
            this.billpayTab.Controls.Add(this.txtAmount);
            this.billpayTab.Location = new System.Drawing.Point(4, 22);
            this.billpayTab.Name = "billpayTab";
            this.billpayTab.Padding = new System.Windows.Forms.Padding(3);
            this.billpayTab.Size = new System.Drawing.Size(725, 266);
            this.billpayTab.TabIndex = 0;
            this.billpayTab.Text = "Billpay";
            this.billpayTab.UseVisualStyleBackColor = true;
            // 
            // clickOk
            // 
            this.clickOk.Location = new System.Drawing.Point(65, 58);
            this.clickOk.Name = "clickOk";
            this.clickOk.Size = new System.Drawing.Size(75, 23);
            this.clickOk.TabIndex = 0;
            this.clickOk.Text = "Purchase";
            this.clickOk.UseVisualStyleBackColor = true;
            this.clickOk.Click += new System.EventHandler(this.clickOk_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 32);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(42, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Transid";
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(6, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(53, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Amount";
            // 
            // txtTrans
            // 
            this.txtTrans.Location = new System.Drawing.Point(65, 32);
            this.txtTrans.Name = "txtTrans";
            this.txtTrans.Size = new System.Drawing.Size(206, 20);
            this.txtTrans.TabIndex = 1;
            // 
            // txtAmount
            // 
            this.txtAmount.Location = new System.Drawing.Point(65, 3);
            this.txtAmount.Name = "txtAmount";
            this.txtAmount.Size = new System.Drawing.Size(206, 20);
            this.txtAmount.TabIndex = 0;
            // 
            // topUp
            // 
            this.topUp.Location = new System.Drawing.Point(4, 22);
            this.topUp.Name = "topUp";
            this.topUp.Padding = new System.Windows.Forms.Padding(3);
            this.topUp.Size = new System.Drawing.Size(725, 266);
            this.topUp.TabIndex = 1;
            this.topUp.Text = "TopUp";
            this.topUp.UseVisualStyleBackColor = true;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(22, 318);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(69, 13);
            this.label3.TabIndex = 1;
            this.label3.Text = "Login Status:";
            // 
            // sttLogin
            // 
            this.sttLogin.AutoSize = true;
            this.sttLogin.Location = new System.Drawing.Point(97, 318);
            this.sttLogin.Name = "sttLogin";
            this.sttLogin.Size = new System.Drawing.Size(0, 13);
            this.sttLogin.TabIndex = 2;
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(765, 340);
            this.Controls.Add(this.sttLogin);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.tabController);
            this.Name = "Form2";
            this.Text = "Form2";
            this.Load += new System.EventHandler(this.Form2_Load);
            this.tabController.ResumeLayout(false);
            this.billpayTab.ResumeLayout(false);
            this.billpayTab.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TabControl tabController;
        private System.Windows.Forms.TabPage billpayTab;
        private System.Windows.Forms.TabPage topUp;
        private System.Windows.Forms.TextBox txtTrans;
        private System.Windows.Forms.TextBox txtAmount;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button clickOk;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label sttLogin;
    }
}
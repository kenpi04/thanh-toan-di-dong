﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using cryption;
using MSGateClient.MSGatewayProxy;

namespace MSGateClient
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            sttLogin.Text = login();
        }

        private void clickOk_Click(object sender, EventArgs e)
        {

        }

        private string login()
        {
            string username = "plaptest";
            string password = "plap@pwd";
            string agentpin = "000000";
            string dataSign = "";

            string publicKeyPath = "public.pke"; // duong dan toi public key de ma hoa/ verify
            string privateKeyPath = "private.plaptest.kez"; // duong dan toi private key de sign du lieu

            Cryption cr = new Cryption();
            password = Cryption.EncryptMessage(password, cr.GetKeyFromFile(publicKeyPath));
            agentpin = Cryption.EncryptMessage(agentpin, cr.GetKeyFromFile(publicKeyPath));
            dataSign = cr.signData(username + "_" + password, cr.GetKeyFromFile(privateKeyPath));

            MSFunctionClient client = new MSFunctionClient();
            LoginResponse loginRes = new LoginResponse();
            loginRes = client.login(username, password, "", dataSign);
            int result = loginRes.resultCode;
            string description = loginRes.description;
            return description;
            //label1.Text = result + "-";
            //label1.Text += description;

        }

      
    }
}

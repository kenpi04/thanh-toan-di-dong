﻿namespace MSGateClient
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form3));
            this.billPayTab = new System.Windows.Forms.TabControl();
            this.billpay = new System.Windows.Forms.TabPage();
            this.label8 = new System.Windows.Forms.Label();
            this.txtBillPayId = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtAcc = new System.Windows.Forms.TextBox();
            this.sttBillPay = new System.Windows.Forms.Label();
            this.purBillpay = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.txtAmountBillPay = new System.Windows.Forms.TextBox();
            this.topUpTab = new System.Windows.Forms.TabPage();
            this.button1 = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.txtPhoneTopUp = new System.Windows.Forms.TextBox();
            this.topUpStt = new System.Windows.Forms.Label();
            this.okTopUp = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.txtAmountTopup = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.sttLogin = new System.Windows.Forms.Label();
            this.loginStt = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label11 = new System.Windows.Forms.Label();
            this.billPayTab.SuspendLayout();
            this.billpay.SuspendLayout();
            this.topUpTab.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // billPayTab
            // 
            this.billPayTab.Controls.Add(this.billpay);
            this.billPayTab.Controls.Add(this.topUpTab);
            this.billPayTab.Location = new System.Drawing.Point(46, 110);
            this.billPayTab.Name = "billPayTab";
            this.billPayTab.SelectedIndex = 0;
            this.billPayTab.Size = new System.Drawing.Size(526, 175);
            this.billPayTab.TabIndex = 0;
            // 
            // billpay
            // 
            this.billpay.Controls.Add(this.label8);
            this.billpay.Controls.Add(this.txtBillPayId);
            this.billpay.Controls.Add(this.label7);
            this.billpay.Controls.Add(this.txtAcc);
            this.billpay.Controls.Add(this.sttBillPay);
            this.billpay.Controls.Add(this.purBillpay);
            this.billpay.Controls.Add(this.label2);
            this.billpay.Controls.Add(this.txtAmountBillPay);
            this.billpay.Location = new System.Drawing.Point(4, 22);
            this.billpay.Name = "billpay";
            this.billpay.Padding = new System.Windows.Forms.Padding(3);
            this.billpay.Size = new System.Drawing.Size(518, 149);
            this.billpay.TabIndex = 0;
            this.billpay.Text = "Billpay";
            this.billpay.UseVisualStyleBackColor = true;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(6, 80);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(51, 13);
            this.label8.TabIndex = 8;
            this.label8.Text = "Billpay ID";
            // 
            // txtBillPayId
            // 
            this.txtBillPayId.Location = new System.Drawing.Point(74, 77);
            this.txtBillPayId.Name = "txtBillPayId";
            this.txtBillPayId.Size = new System.Drawing.Size(170, 20);
            this.txtBillPayId.TabIndex = 7;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(6, 45);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(61, 13);
            this.label7.TabIndex = 6;
            this.label7.Text = "Account ID";
            // 
            // txtAcc
            // 
            this.txtAcc.Location = new System.Drawing.Point(74, 42);
            this.txtAcc.Name = "txtAcc";
            this.txtAcc.Size = new System.Drawing.Size(170, 20);
            this.txtAcc.TabIndex = 5;
            // 
            // sttBillPay
            // 
            this.sttBillPay.AutoSize = true;
            this.sttBillPay.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sttBillPay.Location = new System.Drawing.Point(250, 6);
            this.sttBillPay.Name = "sttBillPay";
            this.sttBillPay.Size = new System.Drawing.Size(71, 13);
            this.sttBillPay.TabIndex = 4;
            this.sttBillPay.Text = "BillPay Status";
            // 
            // purBillpay
            // 
            this.purBillpay.Location = new System.Drawing.Point(74, 113);
            this.purBillpay.Name = "purBillpay";
            this.purBillpay.Size = new System.Drawing.Size(75, 23);
            this.purBillpay.TabIndex = 4;
            this.purBillpay.Text = "Purchase";
            this.purBillpay.UseVisualStyleBackColor = true;
            this.purBillpay.Click += new System.EventHandler(this.purBillpay_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(43, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Amount";
            // 
            // txtAmountBillPay
            // 
            this.txtAmountBillPay.Location = new System.Drawing.Point(74, 6);
            this.txtAmountBillPay.Name = "txtAmountBillPay";
            this.txtAmountBillPay.Size = new System.Drawing.Size(170, 20);
            this.txtAmountBillPay.TabIndex = 0;
            // 
            // topUpTab
            // 
            this.topUpTab.Controls.Add(this.button1);
            this.topUpTab.Controls.Add(this.label4);
            this.topUpTab.Controls.Add(this.txtPhoneTopUp);
            this.topUpTab.Controls.Add(this.topUpStt);
            this.topUpTab.Controls.Add(this.okTopUp);
            this.topUpTab.Controls.Add(this.label6);
            this.topUpTab.Controls.Add(this.txtAmountTopup);
            this.topUpTab.Location = new System.Drawing.Point(4, 22);
            this.topUpTab.Name = "topUpTab";
            this.topUpTab.Padding = new System.Windows.Forms.Padding(3);
            this.topUpTab.Size = new System.Drawing.Size(518, 149);
            this.topUpTab.TabIndex = 1;
            this.topUpTab.Text = "TopUp";
            this.topUpTab.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(91, 94);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 15;
            this.button1.Text = "Purchase";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(6, 56);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(78, 13);
            this.label4.TabIndex = 12;
            this.label4.Text = "Phone Number";
            // 
            // txtPhoneTopUp
            // 
            this.txtPhoneTopUp.Location = new System.Drawing.Point(91, 53);
            this.txtPhoneTopUp.Name = "txtPhoneTopUp";
            this.txtPhoneTopUp.Size = new System.Drawing.Size(170, 20);
            this.txtPhoneTopUp.TabIndex = 11;
            // 
            // topUpStt
            // 
            this.topUpStt.AutoSize = true;
            this.topUpStt.Location = new System.Drawing.Point(267, 12);
            this.topUpStt.Name = "topUpStt";
            this.topUpStt.Size = new System.Drawing.Size(71, 13);
            this.topUpStt.TabIndex = 9;
            this.topUpStt.Text = "Topup Status";
            // 
            // okTopUp
            // 
            this.okTopUp.Location = new System.Drawing.Point(74, 185);
            this.okTopUp.Name = "okTopUp";
            this.okTopUp.Size = new System.Drawing.Size(75, 23);
            this.okTopUp.TabIndex = 10;
            this.okTopUp.Text = "Purchase";
            this.okTopUp.UseVisualStyleBackColor = true;
            this.okTopUp.Click += new System.EventHandler(this.okTopUp_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(6, 15);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(43, 13);
            this.label6.TabIndex = 7;
            this.label6.Text = "Amount";
            // 
            // txtAmountTopup
            // 
            this.txtAmountTopup.Location = new System.Drawing.Point(91, 12);
            this.txtAmountTopup.Name = "txtAmountTopup";
            this.txtAmountTopup.Size = new System.Drawing.Size(170, 20);
            this.txtAmountTopup.TabIndex = 5;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(43, 296);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(78, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Login Status";
            // 
            // sttLogin
            // 
            this.sttLogin.AutoSize = true;
            this.sttLogin.Location = new System.Drawing.Point(320, 255);
            this.sttLogin.Name = "sttLogin";
            this.sttLogin.Size = new System.Drawing.Size(0, 13);
            this.sttLogin.TabIndex = 2;
            // 
            // loginStt
            // 
            this.loginStt.AutoSize = true;
            this.loginStt.ForeColor = System.Drawing.Color.Red;
            this.loginStt.Location = new System.Drawing.Point(127, 296);
            this.loginStt.Name = "loginStt";
            this.loginStt.Size = new System.Drawing.Size(0, 13);
            this.loginStt.TabIndex = 3;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(46, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(108, 92);
            this.pictureBox1.TabIndex = 4;
            this.pictureBox1.TabStop = false;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.Brown;
            this.label11.Location = new System.Drawing.Point(160, 36);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(250, 39);
            this.label11.TabIndex = 5;
            this.label11.Text = "Mservice Client";
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(608, 327);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.loginStt);
            this.Controls.Add(this.sttLogin);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.billPayTab);
            this.Name = "Form3";
            this.Text = "Mservice Client";
            this.Load += new System.EventHandler(this.Form3_Load);
            this.billPayTab.ResumeLayout(false);
            this.billpay.ResumeLayout(false);
            this.billpay.PerformLayout();
            this.topUpTab.ResumeLayout(false);
            this.topUpTab.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TabControl billPayTab;
        private System.Windows.Forms.TabPage billpay;
        private System.Windows.Forms.TabPage topUpTab;
        private System.Windows.Forms.TextBox txtAmountBillPay;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label sttLogin;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button purBillpay;
        private System.Windows.Forms.Label loginStt;
        private System.Windows.Forms.Label sttBillPay;
        private System.Windows.Forms.Label topUpStt;
        private System.Windows.Forms.Button okTopUp;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtAmountTopup;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtPhoneTopUp;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtAcc;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtBillPayId;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label11;
    }
}